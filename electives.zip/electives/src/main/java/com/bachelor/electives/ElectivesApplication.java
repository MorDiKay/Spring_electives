package com.bachelor.electives;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectivesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectivesApplication.class, args);
	}

}
