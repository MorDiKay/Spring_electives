package com.bachelor.electives;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectivesApplicationTests {

	@Test
	void contextLoads() {
	}

}
